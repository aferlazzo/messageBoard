See here for more info: https://github.com/adafruit/Adafruit_CircuitPython_Bundle
See VERSIONS.txt for version info.
