# class iBeacon(Advertisement):
#     # Apple manufacturer data with subtype 2
#     match_prefixes = (b"\xff\x00\x4c\x02",)
#
#     proximity_uuid =
#     major =
#     minor =
#     signal_power =
#
